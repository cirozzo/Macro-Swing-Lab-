# Macro Swing Lab 6.0 — Fase 2.9

## Risultato reale

Abbiamo costruito un registro operativo per tutte le 36 serie e un elenco di priorità per la verifica documentale. Abbiamo inoltre verificato **esempi specifici del calendario ufficiale 2026** per BLS e BEA, non una cronologia completa 2007–2026. Nessun valore è stato ammesso ai backtest per effetto di questo lavoro.

## File
- `risultati/registro_fonti_69.csv`: enti candidati, link di ricerca, stato della verifica e blocco dei backtest.
- `risultati/priorita_verifiche_69.csv`: priorità e quantità di lacune e derivati da investigare.
- `risultati/esempi_pubblicazioni_verificate_69.csv`: esempi documentati di date e orari, limitati al 2026. Una data futura prevista non è prova di una pubblicazione già avvenuta.
- `risultati/report_69.json`: riepilogo e limitazioni.

## Requisiti di certificazione
1. Identificare il calendario **storico** di ciascuna release, non applicare il calendario corrente retroattivamente.
2. Associare la singola osservazione al rilascio che l'ha resa nota; non confondere data di riferimento e data di rilascio.
3. Verificare la versione/vintage storica e l'ora effettiva di disponibilità rispetto al timestamp del segnale.
4. Per le serie derivate, verificare componenti nella stessa data di osservazione, metodo, unità e provenienza.
5. Ammettere ai backtest soltanto righe con evidenze registrate e verifiche superate. Le altre restano bloccate.

## GitHub
Non occorre installare file su GitHub in questa fase: si tratta di un audit documentale preliminare. La prossima implementazione dovrà acquisire e versionare i calendari storici ufficiali e produrre un gate automatico di ammissione.

## Riferimenti ufficiali
- BLS: https://www.bls.gov/schedule/2026/10_sched_list.htm
- BEA: https://www.bea.gov/news/schedule/
- ALFRED API: https://fred.stlouisfed.org/docs/api/fred/series_observations.html

**Attenzione:** i link di ricerca nel registro non dimostrano da soli l'origine o la disponibilità storica di una serie.
