# Audit PIT integrato

{
  "serie": 36,
  "snapshot": 37224,
  "esiti": {
    "NON_DISPONIBILE": 6381,
    "NON_VERIFICABILE": 30843
  },
  "calendari_eventi": 69761,
  "serie_con_calendario": 36,
  "errori_fonti": 0,
  "anomalie": 0,
  "strict_certificati": 0,
  "limite": "Calendari FRED e vintage_asof NON certificano da soli timestamp di pubblicazione, valore iniziale e revisioni. Gate fail-closed."
}
