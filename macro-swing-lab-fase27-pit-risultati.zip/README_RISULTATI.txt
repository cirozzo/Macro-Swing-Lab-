Fase27: 36 macro PIT storiche + Fase26, zero nuovi download FRED.
features_*: predittori separati dalle outcomes_*_SOLO_TEST.
Ogni macro snapshot e' disponibile dal giorno UTC successivo alla data_segnale della ricerca originale.
Non equivale a una certificazione intraday ne' al rilascio effettivo del COT.
Per output e copertura vedi audit_fase27.json.
