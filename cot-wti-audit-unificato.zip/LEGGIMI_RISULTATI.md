# Macro Swing Lab — certificazione COT WTI

**Strutturale:** PASSED_SOURCE_RECONCILED
**Point-in-time:** NOT_CERTIFIED

## Limitazioni
- Intervalli 6/8 giorni presenti nei file CFTC: conservati e documentati
- Variazioni >5pp presenti nei file CFTC: conservate e documentate
- Calendario storico ufficiale delle date di rilascio non fornito: PIT NON CERTIFICATO; vietato usare martedì+6 come prova
